# Website Kantor / Profil Bandung

Website statis modern dan responsif yang dibuat dari bahan paket `halaman-profil-bandung(1).rar`.

## Fitur
- Responsive desktop, tablet, dan mobile
- Navigasi mobile
- SEO meta tags + Open Graph
- JSON-LD Schema.org
- Hero, profil, layanan, destinasi
- Testimoni klien
- Blog pribadi / artikel
- Form kontak yang membuka aplikasi email
- Integrasi Instagram, Facebook, YouTube
- Struktur mudah diedit tanpa framework

## Cara menjalankan
1. Ekstrak ZIP.
2. Buka `index.html` di browser, atau gunakan VS Code + Live Server.
3. Untuk publikasi, upload seluruh folder ke hosting seperti GitHub Pages, Netlify, Vercel, atau hosting cPanel.

## Yang perlu Anda ganti
- `info@profilbandung.id`
- Nomor telepon
- Link Instagram/Facebook/YouTube
- `https://example.com/` pada canonical dan JSON-LD
- Isi testimoni dan artikel
- Foto Bosscha/Farm House jika aset gambar tersedia

Catatan: aset `geografis.jpg` dari paket awal sudah dipakai langsung pada website.
