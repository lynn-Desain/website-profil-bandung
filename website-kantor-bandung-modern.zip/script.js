const toggle=document.querySelector(".nav-toggle");
const links=document.querySelector(".nav-links");
toggle?.addEventListener("click",()=>{const open=links.classList.toggle("open");toggle.setAttribute("aria-expanded",open)});
document.querySelectorAll(".nav-links a").forEach(a=>a.addEventListener("click",()=>links.classList.remove("open")));
document.getElementById("year").textContent=new Date().getFullYear();

document.getElementById("contactForm").addEventListener("submit",(e)=>{
  e.preventDefault();
  const f=new FormData(e.target);
  const subject=encodeURIComponent(f.get("subjek"));
  const body=encodeURIComponent(`Nama: ${f.get("nama")}\nEmail: ${f.get("email")}\n\nPesan:\n${f.get("pesan")}`);
  window.location.href=`mailto:info@profilbandung.id?subject=${subject}&body=${body}`;
  document.getElementById("formNote").textContent="Aplikasi email sedang dibuka. Silakan kirim pesan dari aplikasi email Anda.";
});
